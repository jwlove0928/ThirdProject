package com.itbank.project;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAO {
	
	@Autowired
	SqlSessionTemplate myBatis;
	
	public void insert(BoardDTO boardDTO) {
		myBatis.insert("bDAO.insert", boardDTO);
		System.out.println("myBatis 호출");
	}
	
	public void update(BoardDTO boardDTO) {
		myBatis.update("bDAO.update", boardDTO);
	}
	
	public void delete(BoardDTO boardDTO) {
		myBatis.delete("bDAO.delete", boardDTO);
	}
	
	public BoardDTO select(BoardDTO boardDTO) {
		return myBatis.selectOne("bDAO.select", boardDTO);
	}
	
	public List<BoardDTO> selectAll(){
		return myBatis.selectList("bDAO.selectAll");
	}
}
